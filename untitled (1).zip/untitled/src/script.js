const topbar = document.querySelector(".topbar");

window.addEventListener("scroll", () => {

  if (window.scrollY > 30) {
    topbar.style.background = "rgba(5,5,5,.96)";
  } else {
    topbar.style.background = "rgba(7,7,7,.82)";
  }

});


document.querySelectorAll('a[href^="#"]').forEach(link => {

  link.addEventListener("click", event => {

    const target = document.querySelector(
      link.getAttribute("href")
    );

    if (!target) return;

    event.preventDefault();

    target.scrollIntoView({
      behavior: "smooth"
    });

  });

});
